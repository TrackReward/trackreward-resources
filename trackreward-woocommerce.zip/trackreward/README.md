# 🛒 TrackReward WooCommerce Plugin

TrackReward is a powerful affiliate tracking solution for WooCommerce. This plugin automatically tracks affiliate-driven visits and purchases without requiring custom code from the merchant.

---

## 🔧 Features

- 🔗 Tracks affiliate visits using click IDs or referral codes
- 💰 Sends purchase events to TrackReward automatically on WooCommerce order completion
- 🧾 Supports coupon-based attribution and affiliate codes
- 🧠 Commission logic handled via the TrackReward backend
- 📊 Logs all API requests and responses for easy debugging
- 🛡️ Requires no manual code changes to the store

---

## 🚀 Installation

1. Download the plugin `.zip` or clone this repository.
2. Upload it to your WordPress site:
   - WP Admin → Plugins → Add New → Upload Plugin
3. Activate the plugin.
4. Go to **Settings → TrackReward**
5. Enter your **TrackReward App ID**
6. Done! All visitor and order tracking happens automatically.

---

## 🧠 How It Works

1. The plugin injects the TrackReward tracking script in the site’s `<head>`.
2. It captures click IDs via URL parameters and stores them in cookies.
3. When an order is completed in WooCommerce, the plugin:
   - Reads affiliate/coupon data from cookies or order
   - Sends a POST request to trackreward
   - Includes customer info, order ID, amount, coupon, and event
4. The TrackReward backend validates and logs the conversion.

---

## 📝 Settings

| Field        | Description                          |
|--------------|--------------------------------------|
| App ID       | Required. Your unique TrackReward App ID (found in TrackReward dashboard) |

---

## 🛠 Debugging

- Logs are saved in: `wp-content/plugins/trackreward-affiliate-tracker/logs/trackreward.log`
- You can view the **last 10 log entries** directly on the settings page.
- Logs include both:
  - 🟡 Outgoing payload
  - 🟢 TrackReward response
  - 🔴 Any errors

---

## ❗ Requirements

- WordPress 5.5+
- WooCommerce 4.0+
- PHP 7.4+

---

## 📤 Uninstalling

- On uninstall, the plugin will:
  - Remove the saved App ID from `wp_options`
  - Delete the local log file if it exists

---

## 🔐 Security

- Input values are sanitized and validated before sending to the API.
- The plugin only sends API requests on confirmed WooCommerce orders.

---

## 🧩 Developer Notes

- `track_id` is generated per order using `order_<id>_<timestamp>` to prevent duplicate events
- Plugin uses `woocommerce_thankyou` action for reliable conversion event firing
- Affiliate attribution is handled via:
  - `click_id` cookie
  - or WooCommerce coupons

---

## 📞 Support

Need help? Contact [TrackReward Support](https://trackreward.com/contact) or reach out to your integration manager.

---

## 📄 License

MIT License – free to use and modify.
