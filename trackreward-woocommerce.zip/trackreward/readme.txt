=== TrackReward for WooCommerce ===
Contributors: trackreward  
Tags: woocommerce, affiliate marketing, conversion tracking, saas  
Requires at least: 5.5  
Tested up to: 6.8  
Requires PHP: 7.4  
Stable tag: 1.0.1  
License: GPLv2 or later  
License URI: https://www.gnu.org/licenses/gpl-2.0.html  

TrackReward enables WooCommerce merchants to track affiliate traffic and conversions without custom code.

== Description ==

TrackReward is a powerful affiliate tracking platform built for e-commerce.  
This plugin allows WooCommerce merchants to:

- Automatically track affiliate referrals and sales
- Attribute orders to affiliate links or coupon codes
- View affiliate-driven conversions in TrackReward
- Enable tracking without writing any custom code

Perfect for marketers, influencers, and SaaS product teams who want to launch referral programs fast.

**Note**: Requires an active [TrackReward](https://trackreward.com) account.

== Installation ==

1. Upload the plugin ZIP via **Plugins > Add New > Upload Plugin**
2. Activate the plugin
3. Go to **Settings > TrackReward**
4. Enter your **TrackReward App ID**
5. You're done!

== Frequently Asked Questions ==

= Is WooCommerce required? =  
Yes, this plugin is designed to work specifically with WooCommerce.

= Is TrackReward free? =  
TrackReward offers a free trial. An active TrackReward account is required to enable tracking.

= Does this plugin require coding? =  
No. Once your App ID is added, tracking runs automatically in the background.

== Screenshots ==

1. TrackReward settings page inside WordPress
2. Auto tracking of conversions from affiliate links

== Changelog ==

= 1.0.1 =
* Improved script injection via `wp_enqueue_script`
* Replaced file system calls with `WP_Filesystem`
* Addressed PHPCS/WPCS warnings for WordPress.org compliance

= 1.0.0 =
* Initial public release

== Upgrade Notice ==

= 1.0.1 =
Recommended upgrade to meet WordPress.org coding standards and security best practices.