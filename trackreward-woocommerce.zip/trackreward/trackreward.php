<?php
/*
Plugin Name: TrackReward for WooCommerce
Plugin URI: https://trackreward.com/docs/integration/woocommerce
Description: Track affiliate visitors and sales using TrackReward via WooCommerce.
Version: 1.0.1
Author: TrackReward
Author URI: https://trackreward.com
License: GPLv2 or later
*/


// Add Settings Page
add_action('admin_menu', 'trackreward_add_settings_page');
add_action('admin_init', 'trackreward_register_settings');
// Send conversion on order complete
add_action('woocommerce_thankyou', 'trackreward_send_conversion', 10, 1);


function trackreward_add_settings_page()
{
    add_options_page(
        'TrackReward Settings',
        'TrackReward',
        'manage_options',
        'trackreward-settings',
        'trackreward_settings_page_html'
    );
}

function trackreward_register_settings()
{
    register_setting('trackreward_settings_group', 'trackreward_app_id', 'sanitize_text_field');
}

function trackreward_settings_page_html()
{
    $is_woocommerce_active = class_exists('WooCommerce');
    $app_id = esc_attr(get_option('trackreward_app_id'));
?>
    <div class="wrap">
        <h1>TrackReward Settings</h1>

        <?php if (!$is_woocommerce_active): ?>
            <div id="woocommerce-warning-modal" style="background: rgba(0, 0, 0, 0.6); position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 9999; display: flex; align-items: center; justify-content: center;">
                <div style="background: #fff; padding: 30px; border-radius: 8px; max-width: 400px; text-align: center; box-shadow: 0 0 10px rgba(0,0,0,0.3);">
                    <h2 style="color: #cc0000;">WooCommerce Required</h2>
                    <p>Please activate WooCommerce to use TrackReward.</p>
                    <button onclick="document.getElementById('woocommerce-warning-modal').style.display='none'" class="button button-primary">OK</button>
                </div>
            </div>
        <?php endif; ?>

        <form method="post" action="options.php" <?php if (!$is_woocommerce_active) echo 'style="pointer-events:none; opacity:0.4;"'; ?>>
            <?php
            settings_fields('trackreward_settings_group');
            do_settings_sections('trackreward_settings_group');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">TrackReward App ID</th>
                    <td><input type="text" name="trackreward_app_id" value="<?php echo esc_attr($app_id); ?>" style="width: 300px;" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
<?php
}

// Enqueue TrackReward tracking script
function trackreward_insert_tracking_script() {
    $app_id = esc_js(get_option('trackreward_app_id'));
    if (!$app_id) return;

    wp_enqueue_script('trackreward-js', 'https://trackreward.com/assets/js/proscript.js', [], '1.0.0', true);
    $inline_script = "Mastutrack._init({ aid: '{$app_id}', state: 'visit' });";
    wp_add_inline_script('trackreward-js', $inline_script);
}
// Hook to enqueue the script
add_action('wp_enqueue_scripts', 'trackreward_insert_tracking_script');

// Send conversion data when an order is completed
function trackreward_send_conversion($order_id)
{
    if (!$order_id) return;

    $order = wc_get_order($order_id);
    if (!$order) return;

    // Get App ID from plugin settings
    $app_id = get_option('trackreward_app_id');
    if (!$app_id) return;

    $track_id = isset($_COOKIE['_pat_track_id']) ? sanitize_text_field(wp_unslash($_COOKIE['_pat_track_id'])) : '';
    $affiliate_code = isset($_COOKIE['_pat_ref_id']) ? sanitize_text_field(wp_unslash($_COOKIE['_pat_ref_id'])) : '';
    $referer_url = isset($_SERVER['HTTP_REFERER']) ? esc_url_raw(wp_unslash($_SERVER['HTTP_REFERER'])) : '';

    $coupon = implode(',', array_map('sanitize_text_field', $order->get_coupon_codes()));

    $customer  = $order->get_user();

    if (empty($affiliate_code) && empty($coupon)) {
        return;
    }

    $body = [
        'account_id'     => $app_id,
        'affiliate_code' => $affiliate_code ?: null,
        'customer_email' => $order->get_billing_email(),
        'customer_uid'   => $customer ? strval($customer->ID) : 'guest_' . $order_id,
        'track_id'       => !empty($track_id) ? $track_id : null,
        'page_url'       => isset($_SERVER['HTTP_HOST']) ? home_url(add_query_arg(null, null)) : '',
        'refferrer_url'  => $referer_url,
        'amount'         => number_format($order->get_total(), 2, '.', ''),
        'event'          => 'woocommerce_order_' . $order_id,
        'quantity'       => $order->get_item_count(),
        'coupon'         => !empty($coupon) ? $coupon : null,
    ];


    require_once ABSPATH . 'wp-admin/includes/file.php';
    global $wp_filesystem;
    WP_Filesystem();

    // Prepare log directory
    $log_dir = plugin_dir_path(__FILE__) . 'logs/';
    $log_file = $log_dir . 'trackreward.log';

    // Create log directory if it doesn't exist
    if (!$wp_filesystem->is_dir($log_dir)) {
        $wp_filesystem->mkdir($log_dir);
    }

    // Get existing log content
    $existing = $wp_filesystem->exists($log_file) ? $wp_filesystem->get_contents($log_file) : '';

    // Log BEFORE sending
    $before_log = gmdate('Y-m-d H:i:s') . " | Order: {$order_id} | 🟡 [TrackReward] Payload:\n" . json_encode($body, JSON_PRETTY_PRINT) . "\n";
    $wp_filesystem->put_contents($log_file, $existing . $before_log, FS_CHMOD_FILE);


    $response = wp_remote_post('https://trackreward.com/api/tracker/v1/track-charge', [
        'method'  => 'POST',
        'headers' => ['Content-Type' => 'application/json'],
        'body'    => json_encode($body),
        'timeout' => 10,
    ]);

    // Re-fetch log content (optional, for strict append-only safety)
    $existing = $wp_filesystem->exists($log_file) ? $wp_filesystem->get_contents($log_file) : '';

    // Log AFTER sending
    if (is_wp_error($response)) {
        $error_log = gmdate('Y-m-d H:i:s') . " | Order: {$order_id} | 🔴 [TrackReward] Error:\n" . $response->get_error_message() . "\n";
        $wp_filesystem->put_contents($log_file, $existing . $error_log, FS_CHMOD_FILE);
    } else {
        $result = json_decode(wp_remote_retrieve_body($response), true);
        $after_log = gmdate('Y-m-d H:i:s') . " | Order: {$order_id} | 🟢 [TrackReward] Response:\n" . json_encode($result, JSON_PRETTY_PRINT) . "\n";
        $wp_filesystem->put_contents($log_file, $existing . $after_log, FS_CHMOD_FILE);
    }
}

// Activation and Uninstall Hooks
register_activation_hook(__FILE__, 'trackreward_activate');

function trackreward_activate()
{
    // Create default option if not set
    if (get_option('trackreward_app_id') === false) {
        add_option('trackreward_app_id', '');
    }

    require_once ABSPATH . 'wp-admin/includes/file.php';
    global $wp_filesystem;
    WP_Filesystem();

    $log_dir = plugin_dir_path(__FILE__) . 'logs/';
    if (!$wp_filesystem->is_dir($log_dir)) {
        $wp_filesystem->mkdir($log_dir);
    }
}

register_uninstall_hook(__FILE__, 'trackreward_uninstall');

function trackreward_uninstall()
{
    // Remove saved App ID
    delete_option('trackreward_app_id');

    // Initialize WordPress filesystem
    require_once ABSPATH . 'wp-admin/includes/file.php';
    global $wp_filesystem;
    WP_Filesystem();

    $log_dir = plugin_dir_path(__FILE__) . 'logs/';
    $log_file = $log_dir . 'trackreward.log';

    // Delete log file if it exists
    if ($wp_filesystem->exists($log_file)) {
        $wp_filesystem->delete($log_file);
    }

    // Delete log directory if it exists and is empty
    if ($wp_filesystem->is_dir($log_dir)) {
        $files_in_dir = $wp_filesystem->dirlist($log_dir);
        if (empty($files_in_dir)) {
            $wp_filesystem->delete($log_dir, true); // 'true' means recursive
        }
    }
}
